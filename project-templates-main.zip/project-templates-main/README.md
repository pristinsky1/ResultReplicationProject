# Project Templates

This repository contains toy implementations of a data science project
using Cookie Cutter Data Science type templates.

Checkout out different branches for different examples.

### Branches

* `skeleton`: skeleton code for a simple example

